<?php
// koneksi database
include 'koneksi.php';

//menangkap data yang di kirim dari form
$nipd = $_POST['nama'];
$nama = $_POST['nipd'];
$kelas = $_POST['kelas'];
$jurusan = $_POST['jurusan'];

// mengimput data ke database
mysqli_query($koneksi,"insert into tb_siswa values('', '$nama','$nipd', '$kelas', '$jurusan')");

// mengalihkan halaman kemabli ke index.php
header("location:tampil.php");

?>