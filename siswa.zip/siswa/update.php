<?php
// koneksi databse
include 'koneksi.php';

// menangkap data yang dikirim dari form
$id = $_POST['id'];
$nipd = $_POST['nama'];
$nama = $_POST['nipd'];
$kelas = $_POST['kelas'];
$jurusan = $_POST['jurusan'];

// update data ke database
mysqli_query($koneksi,"update tb_siswa set nama='$nama', kelas='$kelas',nipd='$nipd', jurusan='$jurusan' where id='$id'");


// mengalihkan halaman kemabli ke index.php
header("location:tampil.php");
?>