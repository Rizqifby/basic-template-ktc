<?php
// koneksi database
include 'koneksi.php';

// menangkap data id yang di kirim dari url
$id = $_GET['id'];

// menghapus data dari database
mysqli_query($koneksi,"delete from tb_siswa where id='$id'");

// mengalihkan kembali ke halaman index.php
header("location:tampil.php");

?>